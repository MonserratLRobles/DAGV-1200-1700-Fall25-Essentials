To begin, right-click on your .zip file and select "Extract All".
Drag or copy the main folder "Summer Backgrounds Pixel Art" into your existing Unity project to import all the necessary resources.
For more details, read the "How to use it" manual in the Documents folder.

Font that was used for the background of the preview:
https://www.dafont.com/pixellari.font