1. To begin, right-click on your .zip file and select "Extract All".

2. Drag or copy the main folder "Sky Backgrounds Pixel Art 4" into your existing Unity project to import all the necessary resources.

3. Go to the Scenes folder and select a scene to try it out ! 

For more details, read the "How to use it" manual in the Documents folder.


Font that was used for the background of the preview:
https://www.dafont.com/pixellari.font


Did this Unity build help you save time ? 
Support the official partner developer Krawper on Patreon :
https://www.patreon.com/cw/Krawper
